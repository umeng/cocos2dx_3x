//
//  UMSSinaDataTypeTableViewController.h
//  SocialSDK
//
//  Created by umeng on 16/4/7.
//  Copyright © 2016年 dongjianxiong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMSocialCore/UMSocialCore.h>

@interface UMSocialSinaHandler : UMSocialHandler

+ (UMSocialSinaHandler *)defaultManager;


@end
